Ensure that you have the latest Xcode installed through the Mac App Store.
