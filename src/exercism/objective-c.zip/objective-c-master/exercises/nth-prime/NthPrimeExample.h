@interface NthPrime : NSObject {

}
+(int)primeNum:(int)primeNum;
+(BOOL)isPrime:(int)i;
@end