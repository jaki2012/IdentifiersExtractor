#import <Foundation/Foundation.h>

@interface AllYourBase : NSObject

+ (NSArray<NSNumber *> *)outputDigitsForInputBase:(int)inputBase inputDigits:(NSArray<NSNumber *> *)inputDigits outputBase:(int)outputBase;

@end
