#import <Foundation/Foundation.h>

@interface Pangram : NSObject

+ (BOOL)isPangram:(NSString *)text;

@end
