//
//  TwoFerExample.h
//  xobjectivecTest
//
//  Created by Rob Hudson on 11/30/17.
//  Copyright © 2017 exercism. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TwoFer : NSObject

+ (nonnull NSString *)twoFerWithName:(nullable NSString *)name;

@end
