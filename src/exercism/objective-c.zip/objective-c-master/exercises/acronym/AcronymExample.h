#import <Foundation/Foundation.h>

@interface Acronym : NSObject

+ (NSString *)abbreviate:(NSString *)text;

@end
