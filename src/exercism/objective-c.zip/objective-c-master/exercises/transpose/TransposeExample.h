#import <Foundation/Foundation.h>

@interface Transpose : NSObject

+ (NSArray<NSString *> *)transpose:(NSArray<NSString *> *)input;

@end
