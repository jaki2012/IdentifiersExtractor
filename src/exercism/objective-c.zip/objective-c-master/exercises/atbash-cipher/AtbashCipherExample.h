#import <Foundation/Foundation.h>

@interface AtbashCipher : NSObject

+ (NSString *)encode:(NSString *)input;

@end
