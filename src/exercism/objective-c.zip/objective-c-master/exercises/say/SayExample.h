#import <Foundation/Foundation.h>

@interface Say : NSObject

+ (NSString *)say:(long)number;

@end
