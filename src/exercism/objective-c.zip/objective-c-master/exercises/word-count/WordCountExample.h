#import <Foundation/Foundation.h>

@interface WordCount : NSObject

- (id)initWithString:(NSString *)string;
- (NSDictionary *)count;

@end

