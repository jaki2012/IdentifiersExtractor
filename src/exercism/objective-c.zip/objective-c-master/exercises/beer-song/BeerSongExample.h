#import <Foundation/Foundation.h>

@interface BeerSongExample : NSObject

-(instancetype)initWithNumberOfBeerBottles:(int)numberOfBottles;
-(NSString*)singBeerSong;
@end
