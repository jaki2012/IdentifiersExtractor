#import <Foundation/Foundation.h>

@interface FlattenArrayExample : NSObject

+ (NSArray *)flattenArray:(NSArray *)list;

@end
