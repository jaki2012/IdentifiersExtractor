#import <Foundation/Foundation.h>

@interface RomanNumerals : NSObject

+ (NSString *)romanNumeralsForValue:(int)value;

@end
