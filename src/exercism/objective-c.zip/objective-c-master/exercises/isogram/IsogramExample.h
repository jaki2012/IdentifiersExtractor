#import <Foundation/Foundation.h>

@interface Isogram : NSObject

+ (BOOL)isIsogram:(NSString *)string;

@end
