#import <Foundation/Foundation.h>

@interface RNATranscription : NSObject
- (NSString *)rnaFromDNAStrand:(NSString *)dnaStrand;
@end
