#import <Foundation/Foundation.h>

@interface Bob : NSObject

- (NSString *)hey:(NSString *)statement;

@end

