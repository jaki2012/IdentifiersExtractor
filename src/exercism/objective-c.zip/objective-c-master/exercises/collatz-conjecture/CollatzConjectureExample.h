#import <Foundation/Foundation.h>

@interface CollatzConjecture : NSObject

+ (NSInteger)stepsForNumber:(NSInteger)number;

@end
