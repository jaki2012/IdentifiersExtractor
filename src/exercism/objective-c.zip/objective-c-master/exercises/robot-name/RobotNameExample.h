#import <Foundation/Foundation.h>

@interface Robot : NSObject

@property (nonatomic,retain,readwrite) NSString *name;
- (void)reset;

@end

