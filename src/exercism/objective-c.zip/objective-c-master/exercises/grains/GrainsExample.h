@interface Grains : NSObject {

}
-(long long)grainsAtSquareNumber:(int)squareNo;
-(long long)grainsAtBoard;
@end