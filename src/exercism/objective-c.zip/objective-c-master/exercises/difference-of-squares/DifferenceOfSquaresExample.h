#import <Foundation/Foundation.h>

@interface DifferenceOfSquares : NSObject

- (instancetype)initWithMax:(int)max;
- (int)squareOfSums;
- (int)sumOfSquares;
- (int)differenceOfSquares;

@end
