#import <Foundation/Foundation.h>

@interface Raindrops : NSObject

- (instancetype)initWithNumber:(int)number;
- (NSString *)sounds;

@end
