#import <Foundation/Foundation.h>

@interface SumOfMultiples : NSObject

+ (NSNumber *)toLimit:(NSNumber *)limit inMultiples:(NSArray<NSNumber *> *)multiples;

@end
