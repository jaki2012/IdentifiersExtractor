#import <Foundation/Foundation.h>

@interface Hamming : NSObject

+ (NSUInteger)compute:(NSString *)firstStrand against:(NSString *)secondStrand;

@end
