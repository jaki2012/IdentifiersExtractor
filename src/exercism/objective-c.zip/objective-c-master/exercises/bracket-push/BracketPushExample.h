#import <Foundation/Foundation.h>

@interface BracketPushExample : NSObject

+ (BOOL)validateBracketPairingAndNestingInString:(NSString*)string;

@end
