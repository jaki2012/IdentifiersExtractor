#import <Foundation/Foundation.h>

@interface Gigasecond : NSObject

- (instancetype)initWithStartDate:(NSDate *)date;
- (NSDate *)gigasecondDate;

@end
