#import <Foundation/Foundation.h>

@interface Sieve : NSObject

+ (NSArray<NSNumber *> *)primesUpTo:(int)limit;

@end
