#import <Foundation/Foundation.h>


@interface Etl : NSObject

+ (NSDictionary *)transform:(NSDictionary *)original;

@end