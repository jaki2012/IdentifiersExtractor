#if !defined(GRAINS_H)
#define GRAINS_H

namespace grains
{

unsigned long long square(int which);

unsigned long long total();

}

#endif
