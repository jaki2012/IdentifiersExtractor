#if !defined(SAY_H)
#define SAY_H

#include <string>

namespace say
{

std::string in_english(unsigned long long number);

}

#endif
