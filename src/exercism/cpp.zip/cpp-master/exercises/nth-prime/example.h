#if !defined(NTH_PRIME_H)
#define NTH_PRIME_H

namespace prime
{
int nth(int n);
}

#endif
