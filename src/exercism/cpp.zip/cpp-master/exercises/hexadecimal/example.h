#if !defined(HEXADECIMAL_H)
#define HEXADECIMAL_H

#include <string>

namespace hexadecimal
{

int convert(const std::string &text);

}

#endif
