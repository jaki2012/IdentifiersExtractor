#if !defined(BINARY_H)
#define BINARY_H

#include <string>

namespace binary
{

int convert(std::string const& text);

}

#endif
