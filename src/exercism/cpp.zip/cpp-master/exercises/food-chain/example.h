#if !defined(FOOD_CHAIN_H)
#define FOOD_CHAIN_H

#include <string>

namespace food_chain
{

std::string verse(unsigned which);
std::string verses(unsigned begin, unsigned end);
std::string sing();

}

#endif
