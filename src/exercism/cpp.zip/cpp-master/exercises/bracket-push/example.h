#if !defined(BRACKET_PUSH_H)
#define BRACKET_PUSH_H 

#include <string>

namespace bracket_push
{

bool check(std::string const& expression);

}

#endif
