#if !defined(DIFFERENCE_OF_SQUARES_H)
#define DIFFERENCE_OF_SQUARES_H

namespace squares
{

int square_of_sums(int n);
int sum_of_squares(int n);
int difference(int n);

}

#endif
