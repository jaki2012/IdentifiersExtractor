#if !defined(RAINDROPS_H)
#define RAINDROPS_H

#include <string>

namespace raindrops
{

std::string convert(int drops);

}

#endif
