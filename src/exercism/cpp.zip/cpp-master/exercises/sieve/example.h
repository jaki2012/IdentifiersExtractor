#if !defined(SIEVE_H)
#define SIEVE_H

#include <vector>

namespace sieve
{

std::vector<int> primes(int n);

}

#endif
