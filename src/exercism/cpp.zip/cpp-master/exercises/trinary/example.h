#if !defined(TRINARY_H)
#define TRINARY_H

#include <string>

namespace trinary
{

int to_decimal(std::string const &text);

}

#endif
