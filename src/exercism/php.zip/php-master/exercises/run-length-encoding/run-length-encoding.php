<?php

//
// This is only a SKELETON file for the "Run Length Encoding" exercise. It's been provided as a
// convenience to get you started writing code faster.
//

function encode($input)
{
    //
    // YOUR CODE GOES HERE
    //
}

function decode($input)
{
    //
    // YOUR CODE GOES HERE
    //
}
