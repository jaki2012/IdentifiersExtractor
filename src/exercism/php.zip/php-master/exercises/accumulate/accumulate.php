<?php

function accumulate(array $input, callable $accumulator)
{
    // YOUR CODE GOES HERE
}
