<?php

include_once 'book-store.php';

/**
 * Calculate lowest price for shopping basket only
 * containing books from a single series. There is no
 * discount advantage for having more than one copy of
 * any single book in a grouping.
 */

class BookStoreTest extends PHPUnit\Framework\TestCase
{

    /**
     * A basket containing only a single book.
     * Target grouping: [[1]]
     */
    public function testSingleBook()
    {
        $basket = [1];
        $this->assertEquals(8.0, total($basket));
    }

    /**
     * A basket containing only two of the same book.
     * Target grouping: [[2], [2]]
     */
    public function testTwoSame()
    {
        $basket = [2, 2];
        $this->assertEquals(16.0, total($basket));
    }

    /**
     * No charge to carry around an empty basket.
     * Target grouping: []
     */
    public function testEmpty()
    {
        $basket = [];
        $this->assertEquals(0.0, total($basket));
    }

    /**
     * A basket containing only two different books.
     * Target grouping: [[1, 2]]
     */
    public function testTwoDifferent()
    {
        $basket = [1, 2];
        $this->assertEquals(15.2, total($basket));
    }

    /**
     * A basket of three different books.
     * Target grouping: [[1, 2, 3]]
     */
    public function testThreeDifferent()
    {
        $basket = [1, 2, 3];
        $this->assertEquals(21.60, total($basket));
    }

    /**
     * A basket of four different books.
     * Target grouping: [[1, 2, 3, 4]]
     */
    public function testFourDifferent()
    {
        $basket = [1, 2, 3, 4];
        $this->assertEquals(25.60, total($basket));
    }

    /**
     * A basket of five different books.
     * Target grouping: [[1, 2, 3, 4, 5]]
     */
    public function testFiveDifferent()
    {
        $basket = [1, 2, 3, 4, 5];
        $this->assertEquals(30.00, total($basket));
    }

    /**
     * A basket containing eight books consisting of a
     * pair each of the first three books plus one copy
     * each of the last two books. Please pay careful
     * attention to this particular target grouping, it
     * is not intuitive, but does grant the largest
     * discount.
     * Target grouping: [[1, 2, 3, 4], [1, 2, 3, 5]]
     */
    public function testEight()
    {
        $basket = [1, 1, 2, 2, 3, 3, 4, 5];
        $this->assertEquals(51.20, total($basket));
    }

    /**
     * A basket containing nine books consisting of a
     * pair each of the first four books plus one of
     * the last book.
     * Target grouping: [[1, 2, 3, 4, 5], [1, 2, 3, 4]],
     */
    public function testFourPairsPlusOne()
    {
        $basket = [1, 1, 2, 2, 3, 3, 4, 4, 5];
        $this->assertEquals(55.60, total($basket));
    }

    /**
     * A basket containing ten books consisting of two
     * copies of each book in the series.
     * Target grouping: [[1, 2, 3, 4, 5], [1, 2, 3, 4, 5]]
     */
    public function testFivePairs()
    {
        $basket = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5];
        $this->assertEquals(60.00, total($basket));
    }

    /**
     * A basket containing eleven books consisting
     * of three copies of the first book plus two each
     * of the remaining four books in the series.
     * Target grouping: [[1, 2, 3, 4, 5], [1, 2, 3, 4, 5], [1]]
     */
    public function testFivePairsPlusOne()
    {
        $basket = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 1];
        $this->assertEquals(68.00, total($basket));
    }

    /**
     * A basket containing twelve books consisting of
     * three copies of the first two books, plus two
     * each of the remaining three books in the series.
     * Target grouping: [[1, 2, 3, 4, 5], [1, 2, 3, 4, 5], [1, 2]]
     */
    public function testTwelve()
    {
        $basket = [1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 1, 2];
        $this->assertEquals(75.20, total($basket));
    }
}
