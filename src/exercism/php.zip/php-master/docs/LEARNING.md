# Recommended Learning Resources

Exercism provides exercises and feedback but can be difficult to jump into for those learning PHP for the first time. These free resources can help you get started:

[Laracasts - The PHP Practitioner Video Tutorials](https://laracasts.com/series/php-for-beginners)  
[PHP Documentation](http://php.net/docs.php)  
[PHP The Right Way](http://www.phptherightway.com/)  
[Codecademy's PHP Course](https://www.codecademy.com/learn/php)  
[StackOverflow](http://stackoverflow.com/questions/tagged/php)  
[PHP Pandas (Online Book)](https://daylerees.com/php-pandas/)
