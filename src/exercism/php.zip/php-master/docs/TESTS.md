Execute the tests with:

```
$ phpunit filename.php
```
