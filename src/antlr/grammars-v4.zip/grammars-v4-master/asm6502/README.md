# 6502 Grammar

An ANTLR4 grammar for [6502 Assember](http://en.wikipedia.org/wiki/6502) files.

You can download appropriate example files at [http://6502.org/](http://6502.org/).

This grammar uses the syntax from the [LISA](http://en.wikipedia.org/wiki/Lisa_assembler) Assembler.