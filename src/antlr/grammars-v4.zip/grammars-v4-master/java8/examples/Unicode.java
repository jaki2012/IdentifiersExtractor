class Unicode {
        public static void main(String[] args) {
                System.out.println("A = \uuu0041");
        }
}
