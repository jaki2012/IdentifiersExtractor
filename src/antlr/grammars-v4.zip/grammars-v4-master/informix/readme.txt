Gregorio Momm Mon Jan 5, 2004 18:17
A 1st attempt of a Infomix 4GL Grammar, works with all the files i tried, but needs some improvements.

Antlr4 port by Tom Everett, 2016

