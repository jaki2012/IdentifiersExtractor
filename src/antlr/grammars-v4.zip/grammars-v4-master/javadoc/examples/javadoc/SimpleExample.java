/**
 * A description text.
 */