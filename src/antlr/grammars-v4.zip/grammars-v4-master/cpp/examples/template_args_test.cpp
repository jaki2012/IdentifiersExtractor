void TemplateArgsTest(vector<ClassA> args, vector <ClassB> args2)
{
}
