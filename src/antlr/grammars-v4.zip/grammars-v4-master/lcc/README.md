# LCC Grammar

An ANTLR4 grammar for [Library of Congress Numbers](https://en.wikipedia.org/wiki/Library_of_Congress_Classification).

