# JPA grammar

Alexander Kunkel Wed May 6, 2009 12:58

Ported to Antlr4 by Tom Everett.

