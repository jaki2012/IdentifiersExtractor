// comment before use strict
"use strict";
let a = 42;