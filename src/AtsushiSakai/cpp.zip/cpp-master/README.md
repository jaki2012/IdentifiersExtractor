cpp
===

c++ sample codes

# DesignPattern
C++によるデザインパターンのサンプルコードです。

# ModernC
モダンなC言語の書き方のサンプルです
