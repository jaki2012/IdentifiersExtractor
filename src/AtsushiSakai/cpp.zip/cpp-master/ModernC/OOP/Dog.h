
#ifndef _DOG_H_
#define _DOG_H_

//オブジェクト作成用マクロ
#define newDog() {Dog_Bark}

//パブリック関数のプロトタイプ宣言
void Dog_Bark(void);

#endif //_DOG_H_
