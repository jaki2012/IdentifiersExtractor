#include<stdio.h>
#include"Dog.h"

//プライベート関数

void Dog_Bark(void){
  printf("ワンワン\n");
}

//====プライベート関数====

