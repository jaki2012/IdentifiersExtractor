#include<stdio.h>
#include"Teacher.h"
#include"Person.h"

//プライベート変数

//プライベート関数

void Teacher_Bark(struct Teacher teacher){
  printf("私の生徒の数は%dです。\n",teacher.nStudent);
}

//====プライベート関数====

