# 安装Python学习助手

首先确认Python 3.4已安装。

# 下载learning.py

下载地址：

[https://raw.githubusercontent.com/michaelliao/learn-python3/master/teach/learning.py](https://raw.githubusercontent.com/michaelliao/learn-python3/master/teach/learning.py)

(右键 - 另存为)

放到某个目录，例如`C:\Work`下。

# 运行命令：

切换到`learning.py`所在目录，运行：

```
C:\Work> python learning.py
```

如果看到`Ready for Python code on port 39093...`表示运行成功，不要关闭命令行窗口，最小化放到后台运行即可。

![run-learning.py.png](https://raw.githubusercontent.com/michaelliao/learn-python3/master/teach/run-learning.py.png)
