//
//  ISTimeline.h
//  ISTimeline
//
//  Created by Max Holzleitner on 07.05.16.
//  Copyright © 2016 instant:solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ISTimeline.
FOUNDATION_EXPORT double ISTimelineVersionNumber;

//! Project version string for ISTimeline.
FOUNDATION_EXPORT const unsigned char ISTimelineVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ISTimeline/PublicHeader.h>


