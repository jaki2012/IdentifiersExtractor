# java8
Sample code for "New Features in Java 8" talk

Good reference:

Java 8 for the Really Impatient by Cay Horstmann